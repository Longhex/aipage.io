export default function ProjectIntegrations({
  params,
}: {
  params: {
    id: string;
  };
}) {
  return <div></div>;
}
